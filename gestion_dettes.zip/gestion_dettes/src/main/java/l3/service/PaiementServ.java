package l3.service;


import l3.data.entity.Paiement;

public interface PaiementServ extends Service<Paiement>  {
    // public void Create(Paiement ob) {
    //     paiementRepo.insert(ob);
    // }
    
}
