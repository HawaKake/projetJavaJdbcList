package l3.service;

import l3.data.entity.Client;

public interface ClientServ extends Service<Client> {

    

    
}