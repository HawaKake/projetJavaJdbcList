package l3.service;

import java.util.ArrayList;

public interface Service <T>{


    public void Create(T ob); 
    ArrayList<T> show();
     
   
   
}
