package l3.service;

import l3.data.entity.Article;


public interface ArticleServ extends Service<Article> {
    
}
