package l3.service;

import l3.data.entity.Client;
import l3.data.entity.Dette;

public interface DetteServ extends Service<Dette>  {


    
} 
