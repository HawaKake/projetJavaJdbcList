package l3.view;

import java.util.ArrayList;
import java.util.Scanner;

import l3.data.entity.Client;
import l3.data.entity.Paiement;

public class PaiementView {
     Scanner scanner = new Scanner(System.in);

    
    public Paiement saisie() {
        double montant;
       do {
        System.out.print("Entrez le montant du paiement : ");
        montant = scanner.nextDouble();
        
       } while (montant <= 0);

       return new Paiement(montant);
       


    }


     public void affiche(ArrayList<Paiement> datas) {
      for (Paiement data : datas) {
           System.out.println(data);   
      }
    } 
}
