package l3.view;

public class View {
    
}
