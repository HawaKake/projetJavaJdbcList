package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.UserRole;

public interface RoleRepoBd extends Repository<UserRole> {
    
}
