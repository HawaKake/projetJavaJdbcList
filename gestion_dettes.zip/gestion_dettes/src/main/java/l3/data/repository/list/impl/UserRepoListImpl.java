package l3.data.repository.list.impl;

import l3.data.entity.User;
import l3.data.entity.UserRole;
import l3.data.repository.list.RoleRepoList;
import l3.data.repository.list.UserRepoList;

public class UserRepoListImpl extends RepositoryListImpl<User> implements UserRepoList{
    
}
