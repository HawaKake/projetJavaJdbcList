package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.Dette;

public interface DetteRepoBD extends Repository<Dette> {
    
}
 