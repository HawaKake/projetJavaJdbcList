package l3.data.repository.list.impl;

import l3.data.entity.Client;
import l3.data.repository.list.ClientRepoList;

public class ClientRepoListImpl extends RepositoryListImpl<Client> implements ClientRepoList{
    
}
