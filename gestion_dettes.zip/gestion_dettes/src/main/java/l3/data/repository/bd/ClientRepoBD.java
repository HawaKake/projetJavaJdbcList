package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.Client;

public interface ClientRepoBD  extends Repository  <Client> {
    
}
  