package l3.data.repository.bd.Impl;

import java.util.ArrayList;

import l3.core.DataBaseImpl;
import l3.data.entity.Detail;
import l3.data.repository.bd.DetailBD;

public class DetailBDImpl extends DataBaseImpl implements DetailBD {

    @Override
    public boolean insert(Detail objet) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'insert'");
    }

    @Override
    public ArrayList<Detail> selectAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'selectAll'");
    }
    
}
