package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.User;

public interface UserRepoBD extends Repository <User> {
    
}
