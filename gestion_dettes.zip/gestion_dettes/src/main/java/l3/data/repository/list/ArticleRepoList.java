package l3.data.repository.list;

import l3.core.Repository;
import l3.data.entity.Article;


public interface ArticleRepoList extends Repository  <Article> {
    
}
