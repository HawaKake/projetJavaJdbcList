package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.Article;

public interface ArticleRepoBD extends Repository  <Article>  {

    
} 