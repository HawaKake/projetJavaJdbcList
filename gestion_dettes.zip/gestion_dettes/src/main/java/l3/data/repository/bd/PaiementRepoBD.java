package l3.data.repository.bd;

import l3.data.entity.Paiement;
import l3.core.Repository;

public interface PaiementRepoBD extends Repository<Paiement>{

    
}