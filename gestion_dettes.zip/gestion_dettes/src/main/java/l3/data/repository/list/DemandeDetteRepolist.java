package l3.data.repository.list;

import l3.core.Repository;
import l3.data.entity.DemandeDeDette;
import l3.data.entity.Dette;

public interface DemandeDetteRepolist extends Repository<DemandeDeDette> {

    
}