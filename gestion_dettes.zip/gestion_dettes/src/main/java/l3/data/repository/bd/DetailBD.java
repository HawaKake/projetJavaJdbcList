package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.Detail;

public interface DetailBD  extends Repository<Detail> {
    
}
