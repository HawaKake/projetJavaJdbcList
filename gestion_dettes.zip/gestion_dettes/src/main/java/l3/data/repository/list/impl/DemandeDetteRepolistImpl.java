package l3.data.repository.list.impl;

import l3.data.entity.Client;
import l3.data.entity.DemandeDeDette;
import l3.data.repository.list.ClientRepoList;
import l3.data.repository.list.DemandeDetteRepolist;

public class DemandeDetteRepolistImpl extends RepositoryListImpl<DemandeDeDette> implements DemandeDetteRepolist {
    
}
