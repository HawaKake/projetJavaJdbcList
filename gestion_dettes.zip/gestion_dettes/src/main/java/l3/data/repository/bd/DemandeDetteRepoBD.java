package l3.data.repository.bd;

import l3.core.Repository;
import l3.data.entity.DemandeDeDette;

public interface DemandeDetteRepoBD extends Repository<DemandeDeDette>{
    
}
