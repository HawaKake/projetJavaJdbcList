package l3.data.repository.list.impl;

import l3.data.entity.Article;
import l3.data.entity.Client;
import l3.data.repository.list.ArticleRepoList;
import l3.data.repository.list.ClientRepoList;

public class ArticleRepoListImpl  extends RepositoryListImpl<Article> implements ArticleRepoList  {
    
}
