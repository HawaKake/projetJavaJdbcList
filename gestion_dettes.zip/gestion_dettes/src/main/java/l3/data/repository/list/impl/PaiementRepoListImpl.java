package l3.data.repository.list.impl;

import l3.data.entity.Client;
import l3.data.entity.Paiement;
import l3.data.repository.list.PaiementRepoList;

public class PaiementRepoListImpl extends RepositoryListImpl<Paiement> implements PaiementRepoList {
    
}
